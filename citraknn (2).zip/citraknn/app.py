from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
import os
from main import BeachPlantClassifier  # class dari file main.py kamu

from flask import send_from_directory

app = Flask(__name__)
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

UPLOAD_FOLDER = 'uploads'
DATASET_PATH = 'dataset'  # pastikan sesuai nama folder dataset kamu
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Inisialisasi model dan latih 1x saat server mulai
classifier = BeachPlantClassifier(k=3)

classifier.train(DATASET_PATH)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def index():
    prediction = None
    confidence = None
    image_filename = None
    probabilities = None

    if request.method == 'POST':
        file = request.files.get('file')
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)

            # Prediksi dari model KNN
            predicted_class, conf, all_probs = classifier.predict(filepath)

            prediction = predicted_class
            confidence = round(conf * 100, 2)
            image_filename = filename
            probabilities = zip(classifier.class_names, all_probs)

    return render_template('index.html',
                           prediction=prediction,
                           confidence=confidence,
                           image_filename=image_filename,
                           probabilities=probabilities)


if __name__ == '__main__':
    app.run(debug=True)
